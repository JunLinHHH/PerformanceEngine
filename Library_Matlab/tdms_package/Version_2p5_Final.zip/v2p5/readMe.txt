See TDMS_Documentation.m for important info.
See private/TDMS_exampleFunctionCalls.m for examples

This folder and the "tdmsSubfunctions" subfolder need to be in the Matlab path

Simplest Usage (I think):
filename = '';
my_tdms_struct = TDMS_getStruct(filename);